#!/usr/bin/env python
# -*- coding:utf-8 -*-

# Session类型：cache/redis/memcached
SESSION_TYPE = "cache"
# Session超时时间（秒）
SESSION_EXPIRES = 60 * 20

LOGIN_URL = '/login'